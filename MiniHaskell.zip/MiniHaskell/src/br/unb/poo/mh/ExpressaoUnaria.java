package br.unb.poo.mh;

public  abstract class ExpressaoUnaria implements Expressao {
	
	protected Expressao Unaria;
	
	public ExpressaoUnaria(Expressao exp){
		this.Unaria=exp;
		
	}
	
	public Expressao getUniaria(){
		return Unaria;
		
	}
	
	public void setUnaria(Expressao Unaria){
		this.Unaria=Unaria;
		
	}
}
