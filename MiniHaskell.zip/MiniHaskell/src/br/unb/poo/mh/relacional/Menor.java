package br.unb.poo.mh.relacional;

import br.unb.poo.mh.Expressao;
import br.unb.poo.mh.ExpressaoBinaria;
import br.unb.poo.mh.Tipo;
import br.unb.poo.mh.Valor;
import br.unb.poo.mh.ValorBooleano;
import br.unb.poo.mh.ValorInteiro;


public class Menor extends ExpressaoBinaria {
	
	
	

	public Menor(Expressao expDireita, Expressao expEsquerda){
		
		super(expDireita,expEsquerda); //chama o construtor da expDireita e expEsquerda
		
	}
	
	@Override
	public Tipo tipo() {
		
		//verifica se o tipo da expressao � booleano
		Tipo TipoExpDir= expDireita.tipo();
		Tipo TipoExpEsq= expDireita.tipo();
		
		if (TipoExpDir.equals(Tipo.Inteiro ) && TipoExpEsq.equals(Tipo.Inteiro)){
			
			return Tipo.Inteiro;
			
			
		}

	

		return Tipo.Error; //funciona como um else
		
		
		
		
		// TODO Auto-generated method stub
		}
	@Override
	
	public Valor avaliar(){
		//implementa a opera��o de subtracao
		
		if(tipo().equals(Tipo.Inteiro)){
			
		
		ValorInteiro Valr1= (ValorInteiro) expDireita.avaliar(); 
		ValorInteiro Valr2 = (ValorInteiro) expEsquerda.avaliar();
		
		return new ValorBooleano (Valr1.getValor() < Valr2.getValor());
		}
		
		return null;
		
	}

	
	

	@Override
	public boolean checarTipo() {
		// TODO Auto-generated method stub
		return tipo().equals(Tipo.Inteiro);
	}

	
	
	
	
}
