# MiniHaskell
###Projeto 2
##T�cnicas de Programa��o 1 ministrada pelo professor Rodrigo Bonif�cio
###2/2016
#####Alunos 

Davi Rabbouni de Carvalho Freitas - 15/0033010

Henrique Brant de Moraes Palmeir�o Alvarenga - 15/0011644

Marcos Vin�cius Prescendo Tonin - 14/0153233

##TODO

a) Novos tipos de express�o:(OK)

* subtra��o;(OK)

* divis�o; (OK)

* and;(OK)

* or;(OK)

* not e;(OK) 

* operadores relacionais: ==, >, <, >=, <=.(OK)

b) Verifica��o de tipos  (Ok)

- lembrar que as fun��es devem ter os argumentos formais tirados

c) Testes unitarios: 90% de cobertura
#### Nota
Verificar Indentificador e 	AplicacaoFuncao

####### Forma de envio:
Enviar arquivo ZIP contendo o codigo fonte + testes unit�rios + arquivo README indicando a equipe. 
