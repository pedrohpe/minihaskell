package br.unb.poo.mh.logica;

import br.unb.poo.mh.Expressao;
import br.unb.poo.mh.ExpressaoBinaria;
import br.unb.poo.mh.Tipo;
import br.unb.poo.mh.Valor;
import br.unb.poo.mh.ValorBooleano;
import br.unb.poo.mh.Visitor;

public class AND extends ExpressaoBinaria{
	
	
	

	public AND(Expressao expDireita, Expressao expEsquerda){
		
		super(expDireita,expEsquerda); //chama o construtor da expDireita e expEsquerda
		
	}
	
	@Override
	
	public Valor avaliar(){
		//implementa a opera��o l�gica and
		ValorBooleano expDir= (ValorBooleano) expDireita.avaliar(); 
		ValorBooleano expEsq = (ValorBooleano) expEsquerda.avaliar();
		
		return new ValorBooleano(expDir.getValor() && expEsq.getValor());
		
	}

	@Override
	public Tipo tipo() {
		
		//verifica se o tipo da expressao � booleano
		Tipo TipoExpDir= expDireita.tipo();
		Tipo TipoExpEsq= expDireita.tipo();
		
		if (TipoExpDir.equals(Tipo.Booleano ) && TipoExpEsq.equals(Tipo.Booleano)){
			
			return Tipo.Booleano;
			
			
		}

		return Tipo.Error; //funciona como um else
		
		
		
		
		// TODO Auto-generated method stub
		}

	@Override
	public boolean checarTipo() {
		// TODO Auto-generated method stub
		return tipo().equals(Tipo.Booleano);
	}

	@Override
	public void aceitar(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visitar(this);
		
	}

	

}
