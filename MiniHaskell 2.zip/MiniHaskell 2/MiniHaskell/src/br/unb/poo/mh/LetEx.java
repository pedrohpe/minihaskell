package br.unb.poo.mh;
import java.util.ArrayList;
import java.util.List;
public class LetEx implements Expressao {
	
	private  String id;
	private Expressao atrib;
	private Expressao expressao;
	
	public LetEx(String id, Expressao atrib, Expressao expressao){
		this.id=id;
		this.atrib=atrib;
		this.expressao=expressao;
		
	}
	

	@Override
	public Valor avaliar() {
		// TODO Auto-generated method stub
		Ambiente.instance().associaExpressao(id,atrib);
		return expressao.avaliar();
		
		
		
	}

	

	@Override
	public Tipo tipo() {
		// TODO Auto-generated method stub
		
		return expressao.tipo();
	
	}
		public String getId(){
			return id;
		}
		
		public Expressao getAtrib(){
			return atrib;
		}
		
		public Expressao getexpressao(){
			return expressao;
		}
	@Override
	public boolean checarTipo() {
		// TODO Auto-generated method stub
		
		return (!tipo().equals(Tipo.Error));
		
	}


	@Override
	public void aceitar(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visitar(this);
		
	}

	
	

}
