package br.unb.poo.mh.logica;

import br.unb.poo.mh.Expressao;
import br.unb.poo.mh.ExpressaoUnaria;
import br.unb.poo.mh.Tipo;
import br.unb.poo.mh.Valor;
import br.unb.poo.mh.ValorBooleano;
import br.unb.poo.mh.Visitor;

public class Not extends ExpressaoUnaria{
	
	
	

	public Not(Expressao Unaria){
		
		super(Unaria); //chama o construtor da expDireita e expEsquerda
		
	}
	
	@Override
	
	public Valor avaliar(){
		//implementa a opera��o l�gica and
		ValorBooleano exp= (ValorBooleano) Unaria.avaliar(); 
	
		
		return new ValorBooleano(!exp.getValor());
		
	}

	@Override
	public Tipo tipo() {
		
		//verifica se o tipo da expressao � booleano
		Tipo TipoExp= Unaria.tipo();
		
		if (TipoExp.equals(Tipo.Booleano )){
			
			return Tipo.Booleano;
			
			
		}

		return Tipo.Error; //funciona como um else
		
		
		
		
		// TODO Auto-generated method stub
		}

	@Override
	public boolean checarTipo() {
		// TODO Auto-generated method stub
		return tipo().equals(Tipo.Booleano);
	}

	@Override
	public void aceitar(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visitar(this);
		
	}

	

}
