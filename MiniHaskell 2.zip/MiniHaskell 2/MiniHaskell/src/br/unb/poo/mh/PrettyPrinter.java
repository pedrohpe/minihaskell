package br.unb.poo.mh;

import br.unb.poo.mh.logica.AND;
import br.unb.poo.mh.logica.Not;
import br.unb.poo.mh.logica.Or;
import br.unb.poo.mh.aritmetica.Divisao;
import br.unb.poo.mh.aritmetica.Multiplicacao;
import br.unb.poo.mh.aritmetica.Soma;
import br.unb.poo.mh.aritmetica.Subtracao;
import br.unb.poo.mh.relacional.Diferente;
import br.unb.poo.mh.relacional.Igual;
import br.unb.poo.mh.relacional.Maior;
import br.unb.poo.mh.relacional.MaiorIgual;
import br.unb.poo.mh.relacional.Menor;
import br.unb.poo.mh.relacional.MenorIgual;
import br.unb.poo.mh.funcao.AplicacaoFuncao;

public class PrettyPrinter implements Visitor{
	String PP= "";
	@Override
	public void visitar(ValorInteiro exp) {
		// TODO Auto-generated method stub
		PP= PP + exp.getValor();
		
	}

	@Override
	public void visitar(ValorBooleano exp) {
		// TODO Auto-generated method stub
		PP = PP + exp.getValor();
	}

	@Override
	public void visitar(Soma exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "+";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(Multiplicacao exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "*";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
		
	}

	@Override
	public void visitar(Divisao exp) {
		// TODO Auto-generated method stub
		
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "/";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
		
	}

	@Override
	public void visitar(Subtracao exp) {
		// TODO Auto-generated method stub
		
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "-";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
		
	}

	@Override
	public void visitar(Diferente exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "/=";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
		
	}

	@Override
	public void visitar(Igual exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "==";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
		
	}

	@Override
	public void visitar(Maior exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + ">";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(Menor exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "<";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(MenorIgual exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "<=";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(MaiorIgual exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + ">=";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(AND exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "&&";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(Or exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.expEsquerda.aceitar(this);
		PP= PP + "||";
		exp.expDireita.aceitar(this);
		PP= PP + ")";
	}

	@Override
	public void visitar(Not exp) {
		// TODO Auto-generated method stub
		PP= PP + "(";
		exp.getUniaria().aceitar(this);
		PP= PP + "!";
		PP= PP + ")";
	}

	@Override
	public void visitar(IfThenElse exp) {
		// TODO Auto-generated method stub
		PP= PP + "if(";
		exp.getCondicao().aceitar(this);
		PP= PP + ")";
		PP= PP + "then";
		exp.getClausulaThen().aceitar(this);
		PP= PP + "else";
		exp.getClausulaElse().aceitar(this);
		
		
	}

	@Override
	public void visitar(AplicacaoFuncao exp) {
		// TODO Auto-generated method stub
		System.out.print(exp.getNome());
		PP= PP + "(";
		int j=0;
		while(j< exp.getParametros().size() - 1){
			exp.getParametros().get(j++).aceitar(this);
			PP= PP + ",";
			
		}
		
		if(j== exp.getParametros().size() -1 ){
			exp.getParametros().get(j++).aceitar(this);
			
		}
		PP = PP + ")";
	}

	@Override
	public void visitar(Identificador exp) {
		// TODO Auto-generted method stub
		PP= PP + exp.getId();
	}

	@Override
	public void visitar(LetEx exp) {
		// TODO Auto-generated method stub
		PP= PP + "let";
		PP= PP + exp.getId();
		PP=PP + "=";
		exp.getexpressao().aceitar(this);
		PP= PP + "in";
		exp.getAtrib().aceitar(this);
		
		
		
		
	}

	
	
	

}

