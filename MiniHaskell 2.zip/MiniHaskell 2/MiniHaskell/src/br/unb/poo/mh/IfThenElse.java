package br.unb.poo.mh;

public class IfThenElse implements Expressao {
	Expressao condicao;
	Expressao clausulaThen;
	Expressao clausulaElse;
	
	

	
	public IfThenElse(Expressao condicao, Expressao clausulaThen, Expressao clausulaElse) {
		this.setCondicao ( condicao);
		this.setClausulaThen (clausulaThen);
		this.setClausulaElse (clausulaElse);
	} 
	
	public Valor avaliar() {
		ValorBooleano valor = (ValorBooleano)condicao.avaliar();
		if(valor.getValor()) {
			return clausulaThen.avaliar();
		}
		return 			clausulaElse.avaliar();
	}

	@Override
	public Tipo tipo() {
		
		Tipo Condicao_if_else= getCondicao().tipo();
		if(Condicao_if_else.equals(Tipo.Booleano)){ //verificao se a condicao de if else � booleano
			if(getClausulaThen().tipo().equals(getClausulaElse().tipo())){ //verifica se os tipos da then e o else sao do mesmo tipo
				 return getClausulaElse().tipo(); //retorna a p tipo da condicao de else
			}
		}
		
		return Tipo.Error;
	}


	@Override
	public boolean checarTipo() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void aceitar(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visitar(this);
	}
	
	
	public Expressao getCondicao(){
		return condicao;
	}
	
	public void  setCondicao(Expressao condicao){
		 this.condicao=condicao;
	}
	
	
	public Expressao getClausulaThen(){
		return clausulaThen;
	}
	
	public void setClausulaThen(Expressao clausulaThen){
		 this.clausulaThen= clausulaThen;
	}
	
	public Expressao getClausulaElse(){
		return clausulaElse;
	}

	public void setClausulaElse(Expressao clausulaElse){
		 this.clausulaElse= clausulaElse;
	}
	
	
}
