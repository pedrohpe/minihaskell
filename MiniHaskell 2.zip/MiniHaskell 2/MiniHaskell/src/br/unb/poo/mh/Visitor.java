package br.unb.poo.mh;

import br.unb.poo.mh.logica.AND;
import br.unb.poo.mh.logica.Not;
import br.unb.poo.mh.logica.Or;
import br.unb.poo.mh.aritmetica.Divisao;
import br.unb.poo.mh.aritmetica.Multiplicacao;
import br.unb.poo.mh.aritmetica.Soma;
import br.unb.poo.mh.aritmetica.Subtracao;
import br.unb.poo.mh.relacional.Diferente;
import br.unb.poo.mh.relacional.Igual;
import br.unb.poo.mh.relacional.Maior;
import br.unb.poo.mh.relacional.MaiorIgual;
import br.unb.poo.mh.relacional.Menor;
import br.unb.poo.mh.relacional.MenorIgual;
import br.unb.poo.mh.funcao.AplicacaoFuncao;

/**
 * Interface com a declaracao dos metodos que 
 * "visitam" aplicando alguma operacao sobre 
 * os elementos sintaticos de uma linguagem 
 * de programacao. 
 * @author rbonifacio
 *
 */
public interface Visitor {
	
	public void visitar(ValorInteiro exp);
	public void visitar(ValorBooleano exp);
	public void visitar(Soma exp);
	public void visitar(Multiplicacao exp);
	public void visitar(Divisao exp);
	public void visitar(Subtracao exp);
	public void visitar(Diferente exp);
	public void visitar(Igual exp);
	public void visitar(Maior exp);
	public void visitar(Menor exp);
	public void visitar(MenorIgual exp);
	public void visitar(MaiorIgual exp);
	public void visitar(AND exp);
	public void visitar(Or exp);
	public void visitar(Not exp);
	public void visitar(IfThenElse exp);
	public void visitar(AplicacaoFuncao exp);
	public void visitar(Identificador exp);
	public void visitar(LetEx exp);
	
}
